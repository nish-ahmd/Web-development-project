Requirements
you need to install
 1.create-react-app
 2.axios
 3.react-router-dom
-----------------------
<<Status>>
> All pages are made using reactjs and styling done using javascript

> I have not implemented form validation and there are issues with databinding

> I have implemented http request on button clicks for all except the 'StdSelect' page

> All links in the code are links to mockeys created in mockey.io for testing purposes
  These links can be replaced with links to localhost server when implementing sql or
  preferrably mongo db.

> Still have to create the page which displays the links to lectures from student account 
  and the page that displays and lets teachers upload new links

------------------------------------------------------------------------------------------
<<--What needs doing?-->>

> implement form validation and databinding

> Make changes to styles

> Create the final pages written in 'status' section

> i have commented on other changes to be made within the source code

> If you do find other errors/improvements to be corrected/made then feel free to do so

-------------------------------------------------------------------------------------------
<<--Addendum-->>

> It would be better if we can demonstrate this page from the computer of he/she who creates the database and backend

> Clone this repository or create a seperate branch and make changes

> Please post whatever changes you have made to our whatsapp group AND comment them in the source code

> If you have any questions post them to the whatsapp group or contact me directly